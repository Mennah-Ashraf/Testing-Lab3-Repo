public class Inventory {
    private int	coffee;
    private int	milk;
    private int	sugar;

    public Inventory(){
    }

    public int	getCoffee() {
        return this.coffee;
    }

    public int	getMilk() {
        return this.milk;
    }

    public int	getSugar() {
        return this.sugar;
    }

    public void setCoffee(int coffee) {
        this.coffee = coffee;
    }

    public void setMilk(int milk) {
        this.milk = milk;
    }

    public void setSugar(int sugar) {
        this.sugar = sugar;
    }
}